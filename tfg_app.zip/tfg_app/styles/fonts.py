from enum import Enum as enum



class Font(enum):
    DEFAULT = "Open+Sans" #+ ":wght@300&display=swap"
    TITLE = "KPMG" #+ ":wght@500&display=swap"
    LOGO = "Montserrat" #+ ":wght@500&display=swap"