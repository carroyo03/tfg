import reflex as rx
import reflex_chakra as rc
from ..styles.styles import Size as size


def navbar()->rx.Component:
    return rx.hstack(
        rx.box(
            rc.image(
                src="/icons/KPMG_NoCP_White.png",
                height=["2em", size.BIG.value, size.BIG.value],
                width=["3em", size.REALLY_BIG.value, size.REALLY_BIG.value],
                margin_left=["0.5em", size.DEFAULT.value, size.DEFAULT.value],
                margin_top=["0.5em", size.DEFAULT.value, size.DEFAULT.value]
            )
        ),
        width="100%",
        padding="1em"
    )